# oibsip_task5
 This Application is a simple android stopwatch project that will work the same as a normal handled timepiece that measures the time elapsed between its activation and deactivation. This application have three buttons that are start,stop and hold
